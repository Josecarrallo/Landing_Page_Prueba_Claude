import { useEffect } from 'react';

function App() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://fast.wistia.com/assets/external/E-v1.js';
    script.async = true;
    document.head.appendChild(script);

    return () => {
      if (script.parentNode) {
        document.head.removeChild(script);
      }
    };
  }, []);

  return (
    <div style={{ 
      width: '100vw',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      padding: '0',
      margin: '0',
      fontFamily: 'Arial, sans-serif',
      backgroundColor: '#000'
    }}>
      <div style={{ 
        width: '95vw',
        maxWidth: '1400px',
        margin: 'auto'
      }}>
        <div style={{ 
          padding: '56.25% 0 0 0', 
          position: 'relative',
          backgroundColor: '#000',
          borderRadius: '8px',
          overflow: 'hidden'
        }}>
          <iframe
            src="https://fast.wistia.net/embed/iframe/nn611u2tzp?autoPlay=true&muted=false&controlsVisibleOnLoad=true&playButton=false&fullscreenButton=true&volumeControl=true"
            allowFullScreen
            allow="autoplay; fullscreen"
            frameBorder="0"
            style={{ 
              position: 'absolute', 
              top: 0, 
              left: 0, 
              width: '100%', 
              height: '100%' 
            }}
            title="Video Stanbury Retreat"
          />
        </div>

        <p style={{ 
          marginTop: '10px', 
          textAlign: 'center',
          fontSize: '16px',
          color: '#00b359',
          fontWeight: 'bold'
        }}>
          ✓ Click the volume icon to hear the video
        </p>
      </div>
    </div>
  );
}

export default App;
